from distutils.core import setup
setup(name='lol',
      version='1.0',
      py_modules=['Gui', 'championserch', 'favorites', 'itemserch', 'search_summoner', 'gmail', 'mysmtplib'],
)

